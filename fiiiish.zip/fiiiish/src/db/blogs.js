
export const blogs= [
    {
        id: 1,
        img: "https://studyhub.themewant.com/wp-content/uploads/2024/03/03-2.jpg" ,
        title: 'Dana White',
        description: 'UI/UX Exparet'
    },
    {
        id: 2,
        img: "https://studyhub.themewant.com/wp-content/uploads/2024/05/09.jpg" ,
        title: 'Blog 2',
        description: 'Announcing the winners the 2023 Education com Story .'
    },
   
    {
        id: 3,
        img :"https://studyhub.themewant.com/wp-content/uploads/2024/05/09.jpg" ,
        title: 'Blog 4',
        description: 'We are praying for our community and platform. '
    },
    {
        id: 4,
        img:"https://studyhub.themewant.com/wp-content/uploads/2024/05/06.jpg" ,
        title: 'Blog 5',
        description: 'Here at First Baptist Cape Coral we believe!  '
    },
    {
        id: 5,
      img:"https://studyhub.themewant.com/wp-content/uploads/2024/05/07.jpg",
        title: 'Blog 6',
        description: 'Delivering What Consumers Really Value?  '
    },
    // {
    //     id: 7,
    //     img: [Blog7Img],
    //     title: 'Blog 7',
    //     description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. '
    // },
    // {
    //     id: 8,
    //     img: [Blog8Img],
    //     title: 'Blog 8',
    //     description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. '
    // },
    // {
    //     id: 9,
    //     img: [Blog9Img],
    //     title: 'Blog 9',
    //     description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. '
    // },
];
