const routes = [
    { name: 'Home', path: '/', content: 'Welcome to the Home page.' },
    { name: 'Blog', path: '/blog', content: 'Maximizing Your Learning Potential: A Guide to StudyHub' },
    { name: 'Contact', path: '/contact', content: 'Get in touch with us on the Contact page.' },
  ];