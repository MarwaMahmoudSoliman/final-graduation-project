const lectures = [
    { title: 'Rock The Street', duration: '21:08' },
    { title: 'Is an Online Financial Advisor Right for You?', duration: '12:21' },
    { title: 'What Does a Financial Advisor Do?', duration: '07:22' },
  ];