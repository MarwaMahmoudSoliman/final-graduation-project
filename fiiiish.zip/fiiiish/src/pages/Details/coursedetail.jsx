import React from 'react';

function coursedetail() {
  return (
    <div>
         
      <h1 style={{textAlign:"center" ,color:"blue" }}> let's learn</h1>
  
      <iframe width="80%" height="415" style={{marginLeft:"180px"}} src="https://www.youtube.com/embed/PHhQuiM2XWI?si=K0MpEHqmeS7iIzh2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    </div>
  );}
  export default coursedetail;